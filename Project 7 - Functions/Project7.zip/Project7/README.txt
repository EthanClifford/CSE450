Name:  Ethan Clifford
Hours to complete project: 12
Feedback:  This project was easy for the most part, however I really got stuck on test case 405 and 505.
Overall, I felt like the difficulty was still good though.


External Sources (Attributions):