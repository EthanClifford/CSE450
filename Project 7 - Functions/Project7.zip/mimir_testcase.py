import unittest

class TestCase(unittest.TestCase):
    def test_1(self):


       
        # Begin Test Case Contents

        from Project7.project import generate_LMAOcode_from_LOLcode
        from Project7.project import generate_ROFLcode_from_LOLcode
        from Project7.interpreter import interpret

        SEED = 0
        STANDARD_INPUT = "abcdef"

        def strip_leading_whitespace(text):
            lines = [line.lstrip() for line in text.splitlines()]
            return '\n'.join(lines)

        def expect_exception(lolcode_str):
            print(f"LOLcode str:\n{lolcode_str}")
            with self.assertRaises(Exception) as e:
                generate_LMAOcode_from_LOLcode(lolcode_str)
            with self.assertRaises(Exception) as e:
                generate_ROFLcode_from_LOLcode(lolcode_str)
            print("Correctly raised exception")

        def check_output(lolcode_str, expected_output):
            print(f"LOLcode str:\n{lolcode_str}")
            lmaocode = generate_LMAOcode_from_LOLcode(lolcode_str)
            print("Generated LMAOcode:")
            print(lmaocode)
            executed_lmao_output = interpret(lmaocode, 'LMAOcode', seed=SEED, standard_input=STANDARD_INPUT)

            self.assertEqual(expected_output, executed_lmao_output)
            roflcode = generate_ROFLcode_from_LOLcode(lolcode_str)
            print("Generated ROFLcode:")
            print(roflcode)
            executed_rofl_output = interpret(roflcode, 'ROFLcode', seed=SEED, standard_input=STANDARD_INPUT)

            self.assertEqual(expected_output, executed_rofl_output)

        lolcode_str = r"""
        HAI 1.450
        VISIBLE WHATEVR
        HOW IZ I count_As YR arg1 ITZ A YARN MKAY
        	I HAS A index ITZ A NUMBR AN ITZ 0
        	I HAS A result ITZ A NUMBR AN ITZ 0
        	IM IN YR LOOP UPPIN index TIL NOT FURSTBIGGR LENGTHZ OF arg1 AN index
        	O RLY? SAEM arg1'Z index AN 'a'
        	YA RLY
        		UPPIN result
        	OIC
        	NOW IM OUTTA YR LOOP
        	FOUND YR result

        IF U SAY SO ITZ A NUMBR 
        VISIBLE I IZ count_As YR "aabbaac" MKAY
        VISIBLE WHATEVR
        KTHXBYE
        """
        check_output(lolcode_str, '49\n4\n97\n')
        lolcode_str = r"""
        HAI 1.450
        VISIBLE WHATEVR
        HOW IZ I make_scream YR ar_length ITZ A NUMBR MKAY
        	I HAS A index ITZ A NUMBR AN ITZ 0
        	I HAS A result ITZ A YARN AN THAR IZ ar_length
        	IM IN YR LOOP UPPIN index TIL NOT FURSTBIGGR LENGTHZ OF result AN index
        		IN result'Z index PUT 'A'
        	NOW IM OUTTA YR LOOP
        	IN result'Z DIFF OF ar_length AN 1 PUT 'H'
        	FOUND YR result

        IF U SAY SO ITZ A YARN 
        VISIBLE I IZ make_scream YR 10 MKAY
        VISIBLE WHATEVR
        KTHXBYE
        """
        check_output(lolcode_str, '49\nAAAAAAAAAH\n97\n')
        lolcode_str = r"""
        HAI 1.450
        VISIBLE WHATEVR
        HOW IZ I trim YR array ITZ LOTZ A TROOFS AN YR length ITZ A NUMBR MKAY
        	I HAS A result ITZ LOTZ A TROOFS AN THAR IZ length
        	I HAS A index ITZ A NUMBR AN ITZ 0

        	IM IN YR LOOP UPPIN index TIL NOT FURSTBIGGR LENGTHZ OF result AN index
        		O RLY? FURSTBIGGR LENGTHZ OF array AN index
        		YA RLY
        		    IN result'Z index PUT array'Z index
        		NO WAI
        			VISIBLE "ending early because no more values"
        			FOUND YR result
        		OIC

        	NOW IM OUTTA YR LOOP
        	FOUND YR result

        IF U SAY SO ITZ LOTZ A TROOFS
        I HAS A original ITZ LOTZ A TROOFS AN THAR IZ 7
        IN original'Z 0 PUT WIN
        IN original'Z 2 PUT WIN
        IN original'Z 3 PUT WIN
        IN original'Z 5 PUT WIN
        IN original'Z 6 PUT WIN
        VISIBLE I IZ trim YR original AN YR 5 MKAY
        VISIBLE original
        VISIBLE I IZ trim YR original AN YR 10 MKAY
        VISIBLE WHATEVR
        KTHXBYE
        """
        check_output(lolcode_str, '49\n10110\n1011011\nending early because no more values\n1011011000\n97\n')
        #lolcode_str = r"""
        #        HAI 1.450
        #        VISIBLE WHATEVR
        #        HOW IZ I max YR arg1 ITZ A NUMBR AN YR arg2 ITZ A NUMBR MKAY
        #        	O RLY? FURSTBIGGR arg1 AN arg2
        #        	YA RLY
        #        		FOUND YR SUM OF arg1 AN 1
        #        	NO WAI
        #        		FOUND YR arg2
        #        	OIC
        #        IF U SAY SO ITZ A NUMBR
        #        VISIBLE I IZ max YR 33 AN YR 7 MKAY
        #        VISIBLE I IZ max YR I IZ max YR 10 AN YR 5 MKAY AN YR 3 MKAY
        #        VISIBLE I IZ max YR I IZ max YR 3 AN YR 4 MKAY AN YR I IZ max YR 5 AN YR I IZ max YR 6 AN YR 7 MKAY MKAY MKAY
        #        KTHXBYE
        #        """
        #check_output(lolcode_str, '49\n34\n12\n7\n')

        #lolcode_str = r"""
        #HAI 1.450
        #HOW IZ I max YR arg1 ITZ LOTZ A NUMBRS AN YR arg2 ITZ A NUMBR MKAY
        #	O RLY? FURSTBIGGR arg1'Z 0 AN arg2
        #	YA RLY
        #		FOUND YR SUM OF arg1'Z 0 AN 1
        #	NO WAI
        #		FOUND YR SUM OF arg2 AN 1
        #	OIC
        #IF U SAY SO ITZ A NUMBR
        #VISIBLE I IZ max YR 5 AN YR 5 MKAY
        #VISIBLE I IZ max YR I IZ max YR 10 AN YR 5 MKAY AN YR 3 MKAY
        #VISIBLE I IZ max YR I IZ max YR 3 AN YR 4 MKAY AN YR I IZ max YR 5 AN YR I IZ max YR 6 AN YR 7 MKAY MKAY MKAY
        #KTHXBYE
        #"""
        #check_output(lolcode_str,"")
        #expect_exception(lolcode_str)

        # End Test Case Contents


if __name__ == '__main__':
    unittest.main()